File source: https://www.kaggle.com/datasets/sachinpatel21/az-handwritten-alphabets-in-csv-format
tutorial: https://pyimagesearch.com/2020/08/17/ocr-with-keras-tensorflow-and-deep-learning/
