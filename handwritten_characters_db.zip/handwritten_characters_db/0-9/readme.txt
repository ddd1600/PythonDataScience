source of data:
Ng Machine Learning Specialization Course 2. End of Week 2 Lab source files


Backup data source (CSV format):
https://www.kaggle.com/datasets/oddrationale/mnist-in-csv